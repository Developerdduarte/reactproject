
function Home() {
  return (
    <div>Tela de home</div>
  )
}

export default Home;