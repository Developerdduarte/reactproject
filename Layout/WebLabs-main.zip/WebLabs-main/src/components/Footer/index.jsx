import { FooterComponent } from "./Footer.style";
import { memo } from "react";

const Footer = memo(() => {
  return (
    <FooterComponent>
        <div>
            <h3>Desenvolvido por Infoarte Software</h3>
            <h4>infoarteSoftware@gmail.com</h4>
            <h4>(49) 9 9999-9999</h4>

        </div>
    </FooterComponent>
  )
});

export default Footer